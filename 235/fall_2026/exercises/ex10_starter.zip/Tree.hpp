// Tree.hpp
// CSCI 235 -- Exercise 10: BST Traversal
// Provided file -- do not modify. Gradescope compiles your submission
// against the original version of this file.

#ifndef TREE_HPP
#define TREE_HPP

#include <vector>

// A node of a binary tree. In this exercise the tree is always a binary
// SEARCH tree: every value in the left subtree is smaller than data, and
// every value in the right subtree is larger.
struct Node {
    int   data;
    Node* left;
    Node* right;
    explicit Node(int d) : data(d), left(nullptr), right(nullptr) {}
};

// ---- Provided (implemented in Tree.cpp; you do not write these) -------------

// Insert value into the BST and return the (possibly new) root.
// A value that is already in the tree is ignored.
Node* insert(Node* root, int value);

// Build a BST by inserting the values in the given order.
Node* buildTree(const std::vector<int>& values);

// Free every node of the tree. Safe to call with nullptr.
void destroy(Node* root);

// ---- Required (you write these in Traversal.cpp) ----------------------------
// None of the functions below may change the tree. Every one of them must
// work on an EMPTY tree (root == nullptr).

// Task A -- recursive traversals. APPEND the data values to out, in the
// order named. Do not clear out and do not sort it.
void inorder(const Node* root, std::vector<int>& out);     // left, node, right
void preorder(const Node* root, std::vector<int>& out);    // node, left, right
void postorder(const Node* root, std::vector<int>& out);   // left, right, node

// Task B -- the same visiting orders WITHOUT recursion: use std::stack.
// Return the values in the order visited. Inside each function use a
// std::stack directly and do not call the function itself; otherwise Task B
// earns no credit.
std::vector<int> inorderIterative(const Node* root);
std::vector<int> preorderIterative(const Node* root);

// Task C -- level-order (breadth-first) traversal with std::queue.
// Return one inner vector per level: result[0] holds the root, result[1] the
// root's children from left to right, and so on. An empty tree returns an
// empty outer vector.
std::vector<std::vector<int>> levelOrder(const Node* root);

// Task D -- measuring a tree.
// height: the number of EDGES on the longest path from the root down to a
//         leaf. A single node has height 0 and an empty tree has height -1.
// countLeaves: the number of nodes that have no children (0 for an empty tree).
int height(const Node* root);
int countLeaves(const Node* root);

#endif
