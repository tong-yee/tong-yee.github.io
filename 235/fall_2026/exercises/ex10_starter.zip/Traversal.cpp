// Traversal.cpp
// CSCI 235 -- Exercise 10: BST Traversal
// Complete the functions below by finishing the TODO sections.
// Submit this file (and only this file) to Gradescope.
// You may add your own helper functions here, but do not change the
// signatures of the required functions.

#include "Tree.hpp"

#include <algorithm>   // std::max
#include <queue>
#include <stack>
#include <vector>

// ---------------------------------------------------------------- Task A
void inorder(const Node* root, std::vector<int>& out) {
    // TODO: recursive. What is the base case? Where does the line that
    // appends root->data go, relative to the two recursive calls?
    (void)root;
    (void)out;
}

void preorder(const Node* root, std::vector<int>& out) {
    // TODO: same structure as inorder; only the position of the visit changes.
    (void)root;
    (void)out;
}

void postorder(const Node* root, std::vector<int>& out) {
    // TODO: same structure again.
    (void)root;
    (void)out;
}

// ---------------------------------------------------------------- Task B
std::vector<int> inorderIterative(const Node* root) {
    std::vector<int> result;
    // TODO: no recursion. Use a std::stack<const Node*> and a traversal
    // pointer named curr. The stack holds the nodes whose own visit, and
    // whose right subtree, are still waiting.
    (void)root;
    return result;
}

std::vector<int> preorderIterative(const Node* root) {
    std::vector<int> result;
    // TODO: no recursion. A stack of nodes still to be processed.
    // Think about the ORDER in which the two children must be pushed.
    (void)root;
    return result;
}

// ---------------------------------------------------------------- Task C
std::vector<std::vector<int>> levelOrder(const Node* root) {
    std::vector<std::vector<int>> levels;
    // TODO: use a std::queue<const Node*>. How many nodes are in the queue
    // at the moment a new level begins?
    (void)root;
    return levels;
}

// ---------------------------------------------------------------- Task D
int height(const Node* root) {
    // TODO: recursive. Empty tree: -1. Single node: 0.
    (void)root;
    return 0;
}

int countLeaves(const Node* root) {
    // TODO: recursive. A leaf has no children. Do not count empty subtrees.
    (void)root;
    return 0;
}
