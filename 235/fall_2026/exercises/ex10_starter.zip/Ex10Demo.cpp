// Ex10Demo.cpp
// CSCI 235 -- Exercise 10: BST Traversal
//
// Provided file -- do not submit this. Build it with:
//
//     g++ -std=c++17 -g Tree.cpp Traversal.cpp Ex10Demo.cpp -o ex10demo
//     ./ex10demo
//
// The expected output is in demo_output.txt. Your output should match it
// exactly once all four tasks are done.

#include "Tree.hpp"

#include <iostream>
#include <string>
#include <vector>

static std::string show(const std::vector<int>& v) {
    std::string s;
    for (std::size_t i = 0; i < v.size(); ++i) {
        if (i > 0) { s += " "; }
        s += std::to_string(v[i]);
    }
    return s;
}

static void runTree(const char* name, const std::vector<int>& insertOrder) {
    Node* root = buildTree(insertOrder);
    std::cout << name << "  (inserted: " << show(insertOrder) << ")\n";

    std::vector<int> a;
    inorder(root, a);
    std::cout << "  inorder            : " << show(a) << "\n";
    a.clear();
    preorder(root, a);
    std::cout << "  preorder           : " << show(a) << "\n";
    a.clear();
    postorder(root, a);
    std::cout << "  postorder          : " << show(a) << "\n";

    std::cout << "  inorderIterative   : " << show(inorderIterative(root)) << "\n";
    std::cout << "  preorderIterative  : " << show(preorderIterative(root)) << "\n";

    std::vector<std::vector<int>> levels = levelOrder(root);
    std::cout << "  levelOrder         :";
    for (std::size_t i = 0; i < levels.size(); ++i) {
        std::cout << " [" << show(levels[i]) << "]";
    }
    std::cout << "\n";

    std::cout << "  height " << height(root) << ", leaves " << countLeaves(root) << "\n\n";
    destroy(root);
}

int main() {
    runTree("Tree 1", {8, 3, 10, 1, 6, 14, 4, 7, 13});
    runTree("Tree 2 (a chain)", {1, 2, 3, 4});
    runTree("Tree 3 (one node)", {5});
    runTree("Tree 4 (empty)", {});
    return 0;
}
