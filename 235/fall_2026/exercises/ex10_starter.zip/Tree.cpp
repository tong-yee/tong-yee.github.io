// Tree.cpp
// CSCI 235 -- Exercise 10: BST Traversal
// Provided file -- do not modify, do not submit. Compile it together with
// your Traversal.cpp (see the handout).

#include "Tree.hpp"

Node* insert(Node* root, int value) {
    if (root == nullptr) { return new Node(value); }
    Node* curr = root;
    while (true) {
        if (value < curr->data) {
            if (curr->left == nullptr) { curr->left = new Node(value); break; }
            curr = curr->left;
        } else if (value > curr->data) {
            if (curr->right == nullptr) { curr->right = new Node(value); break; }
            curr = curr->right;
        } else {
            break;                       // duplicate: ignored
        }
    }
    return root;
}

Node* buildTree(const std::vector<int>& values) {
    Node* root = nullptr;
    for (std::size_t i = 0; i < values.size(); ++i) {
        root = insert(root, values[i]);
    }
    return root;
}

// Uses a vector of pending nodes instead of recursion, so that even a very
// deep tree can be freed.
void destroy(Node* root) {
    std::vector<Node*> pending;
    if (root != nullptr) { pending.push_back(root); }
    while (!pending.empty()) {
        Node* toDelete = pending.back();
        pending.pop_back();
        if (toDelete->left  != nullptr) { pending.push_back(toDelete->left); }
        if (toDelete->right != nullptr) { pending.push_back(toDelete->right); }
        delete toDelete;
    }
}
